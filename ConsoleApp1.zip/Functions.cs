﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
	internal class Functions
	{
		public static void AddProduct()
		{

		}
		public static void SearchProduct()
		{

		}
		public static void DeleteProduct()
		{

		}
	}
}
