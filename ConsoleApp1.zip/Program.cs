﻿// 1. Create a string array 
// 2. Initialize the array with some string values
// 3. User can enter elements from the console until user enter "exit"
// 4. Print the values of the array to the console
// 5. Exit the program

string[] myCars = new string[10];
Console.WriteLine("Add a car brand and close with 'exit'");
int index = 0; // Initialize index to keep track of the current position in the array
while (true)
{
    Console.Write("Add a car brand: ");
    string data = Console.ReadLine();
    if (data.ToLower().Trim() == "exit")
    {
        break;
    }

    myCars[index] = data;
    index++;
}

Array.Resize(ref myCars, index); // Resize the array to the number of entered elements
Console.WriteLine("Unsorted cars list:");
foreach (string car in myCars)
{
    Console.WriteLine(car);
}

// create a copy of the original array and sort it
var myCarsCopy = new string[myCars.Length];
myCars.CopyTo(myCarsCopy, 0); // Copies the elements of myCars to myCarsCopy, starting at index 0
Array.Sort(myCarsCopy); // Sort the copied array
myCars.OrderBy(car => car).ToArray(); // Sort the original array using LINQ

Console.WriteLine("Sorted cars list:");
foreach (var car in myCarsCopy)
    Console.WriteLine(car);


Console.ReadLine(); // Wait for user input before closing the console