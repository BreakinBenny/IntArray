﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace MoneyTrackClasses
{
	internal class MoneyTrack
	{
		public MoneyTrack()
		{
		}

		public MoneyTrack(double amount, double loans, double debts)
		{
			Amount = amount;
			Loans = loans;
			Debts = debts;
		}

		public double Amount { get; set; }
		public double Loans { get; set; }
		public double Debts { get; set; }

		public string GetAmount()
		{
			return Amount.ToString();
		}
		public string GetLoans()
		{
			return Loans.ToString();
		}
		public string GetDebts()
		{
			return Debts.ToString();
		}
		public string GetDueDate()
		{
			DateTime dueDate = DateTime.Now.AddDays(30);
			return dueDate.ToString("MMMM dd, yyyy");
		}

		public string ViewTransactionHistory(double amount, double loans, double debts, string dueDate)
		{
			Console.WriteLine("Your current account balance is: ");
			Console.ForegroundColor = ConsoleColor.Green;
			Console.Write($"{Amount}, ");
			Console.ResetColor();
			Console.Write(" and you have ");
			Console.ForegroundColor = ConsoleColor.DarkMagenta;
			Console.Write($"{Loans} ");
			Console.ResetColor();
			Console.Write("in loans and ");
			Console.ForegroundColor = ConsoleColor.Red;
			Console.Write($"{Debts}");
			Console.ResetColor();
			Console.Write(" in debts to pay.");
			return $"You currently have {amount}, with {loans} in loans and a debt of {debts} that is to be paid no later than {dueDate}.";
		}
	}

	internal class Transaction
	{
		public Transaction()
		{
		}

		public Transaction(string recipent, double amount, string category, string date)
		{
			Recipent = recipent;
			Amount = amount;
			Category = category;
			Date = date;
		}

		public string Recipent { get; set; }
		public double Amount { get; set; }
		public string Category { get; set; }
		public string Date { get; set; }
		public string GetRecipent()
		{
			return Recipent;
		}
		public string GetAmount()
		{
			return Amount.ToString();
		}
		public string GetCategory()
		{
			return Category;
		}
		public string GetDate()
		{
			return Date.ToString();
		}

		public void AddTransaction(List<Transaction> transactions, Transaction newTransaction, double accBalance)
		{
			Console.Write("Who is this transaction with? ");
			RECIPENT:   
			string input = Console.ReadLine();
			if (!String.IsNullOrEmpty(input))
				Recipent = input;
			else
			{
				Console.ForegroundColor = ConsoleColor.Red;
				Console.WriteLine("Please specify the transaction's recipent.");
				Console.ResetColor();
				goto RECIPENT;
			}

			var NumsOnly = new Regex("^[1-9]+,");
			Console.Write($"How much will {Recipent} receive? (Must be positive and no more than {accBalance}, your current balance.): ");
		GIVEMONEY:
			input = Console.ReadLine();
			if(!String.IsNullOrEmpty(input) && (NumsOnly.IsMatch(input) || input == "all"))
			{   //Can be a value or "all" to give the recipent the full balance.
				double inputAmount = input == "all" ? accBalance : Convert.ToDouble(input);
				if (inputAmount > 0 && inputAmount <= accBalance)
				{
					Amount = inputAmount;
					Console.WriteLine($"{Recipent} will receive {Amount}.\n");
				}
				else
				{
					Console.ForegroundColor = ConsoleColor.Red;
					Console.WriteLine("The transaction must be at least above zero and no more than your current balance, please try again.");
					Console.ResetColor();
					goto GIVEMONEY;
				}

			}
			else
			{
				Console.ForegroundColor = ConsoleColor.Red;
				Console.WriteLine("Please specify the transaction's amount.");
				Console.ResetColor();
				goto GIVEMONEY;
			}

			Console.Write("What transaction is this for? (Bills, loans, damages...): ");
		CATEGORY:
			input = Console.ReadLine();
			if (!String.IsNullOrEmpty(input))
			{
				Console.WriteLine($"\n{Recipent} will receive {Amount} for the purpose of: {input}");
				Category = input;
			}
			else
			{
				Console.ForegroundColor = ConsoleColor.Red;
				Console.WriteLine("Please specify the transaction's category.");
				Console.ResetColor();
				goto CATEGORY;
			}

			Date = DateTime.Now.ToString("g");
			Console.WriteLine($"Transaction takes place at {Date}, is this correct? (Y/N)");
		DATEANDCONFIRM:
			input = Console.ReadLine()?.Trim();
			switch (input)
			{
				case "y":
					Console.WriteLine("Great, the transaction will be added to your history.");
					break;
				case "n":
					Console.WriteLine("What is incorrect?\n1: Recipent\n2: Amount\n3: Category");
				CORRECTIONS:
					char charInput = Console.ReadKey().KeyChar;
					switch (charInput)
					{
						case '1':
							Console.WriteLine("\nThe recipent. Who is this transaction with? ");
							goto RECIPENT;
						case '2':
							Console.WriteLine("\nThe amount. How much will the recipent receive? (Must be positive and no more than your current balance.)");
							goto GIVEMONEY;
						case '3':
							Console.WriteLine("\nThe category. What transaction is this for? (Bills, loans, damages...): ");
							goto CATEGORY;
						default:
							Console.WriteLine("Input invalid, try again.");
							goto CORRECTIONS;
					}
				default:
					Console.WriteLine("Input invalid, try again.");
					goto DATEANDCONFIRM;
			}

			//Transaction newTransaction.(Recipent, Amount, Category, Date);
			Console.WriteLine($"\n({Date}): {Recipent} will receive {Amount} for the purposes of: {Category}");
			transactions.Add(newTransaction);
			
		}
		
		public string TransactionDetails()
		{
			return $"{Recipent}: {Amount} for {Category} ({Date})";
		}

		public string ViewTransaction()
		{
			Console.WriteLine($"You have a transaction with {Recipent} for the amount of {Amount} in the category of {Category} on the date of {Date}.");
			return $"You have a transaction with {Recipent} for the amount of {Amount} in the category of {Category} on the date of {Date}.";
		}
	}
}
