﻿using MoneyTrackClasses;
using System.Linq;

MoneyTrack moneytrack = new MoneyTrack(0, 0, 0);
List<Transaction> transactions = new List<Transaction>();
double accBalance = 0;

// This is a simple console application for tracking money.
// It allows the user to view their transaction history, add new
// transactions, edit existing transactions, and save and quit the application.
Console.WriteLine("Welcome to the Money Tracker! How can we help you?");
Console.Write("Would you like to set a starting balance before we begin? (enter Y/N and confirm with Enter)\n");
TITLESCREEN:
string userInput = Console.ReadLine()?.Trim().ToLowerInvariant();
if (userInput == "y")
{
	Console.WriteLine("\nThen please input your starting balance; it must be greater than zero.");
	INPUT:
	accBalance = Convert.ToDouble(Console.ReadLine());
	if (accBalance <= 0)
	{
		Console.ForegroundColor = ConsoleColor.Red;
		Console.WriteLine("Sorry, that is not a valid starting balance. Please try again.");
		Console.ResetColor();
		goto INPUT;
	}
	else
	{
		Console.ForegroundColor = ConsoleColor.Yellow;
		Console.WriteLine("Great, your starting balance is: " + accBalance);
		Console.ResetColor();
	}
}
else if (userInput == "n")
{
	accBalance += 10;
	Console.ForegroundColor = ConsoleColor.Magenta;
	Console.WriteLine("No problem, we will give you starting a balance of: " + accBalance);
	Console.ResetColor();
}
else
{
	Console.WriteLine("Input invalid, try again.");
	goto TITLESCREEN;
}

Console.WriteLine($"\nYour current account balance is {accBalance}. How may we help you?");
START:
Console.WriteLine("1: Show expense(s), income(s), or both\n2: Add a new expense or income\n3: Edit or remove an existing expense/income\n4: Save and Quit");
char charInput = Console.ReadKey().KeyChar;
switch (charInput)
{
	case '1':
		Console.Write("\nYou chose to view your transaction history.");
		// Code to view transaction history goes here
		if (transactions.Count < 1)
		{
			Console.Write(".. but you have no transactions at present.\n\n");
			goto START;
		}
		Console.Write(" Which would you like to see?\n1: Expenses\n2: Incomes\n3: Expenses and Incomes");
		IEnumerable<Transaction> SortedTransactions;
	EXP_AND_INCOM:
		charInput = Console.ReadKey().KeyChar;
		Console.WriteLine();
		switch (charInput)
		{
			case '1':
				// Code to display expenses goes here
				SortedTransactions = transactions.Where(t => string.Equals(t.In_Or_Out, "Expense", StringComparison.OrdinalIgnoreCase));
				Console.WriteLine("Here are your expenses:");
				break;
			case '2':
				// Code to display incomes goes here
				SortedTransactions = transactions.Where(t => string.Equals(t.In_Or_Out, "Income", StringComparison.OrdinalIgnoreCase));
				Console.WriteLine("Here are your incomes:");
				break;
			case '3':
				// Code to display both expenses and incomes goes here
				SortedTransactions = transactions;
				Console.WriteLine("Here are your expenses and incomes:");
				break;
			default:
				Console.WriteLine("Sorry, we don't understand that command. Please try again.");
				goto EXP_AND_INCOM;
		}

		if (!SortedTransactions.Any())
		{
			Console.WriteLine("... But none match your selection.\n");
			Console.ReadLine();
			Console.Clear();
			break;
		}

		Console.Write("What would you like to sort by?\n1: Recipent\n2: Amount\n3: Category\n4: Date?\n");
		char sortChoice = Console.ReadKey().KeyChar;
		Console.WriteLine("And in what order?\n1: Ascending\n2: Descending\n");
		char orderChoice = Console.ReadKey().KeyChar;
		bool descending = orderChoice == '2';

		IOrderedEnumerable<Transaction> orderedTransactions;
		switch (sortChoice)
		{
			case '1': // sort by recipent
				orderedTransactions = descending ? SortedTransactions.OrderByDescending(t => t.Recipent): SortedTransactions.OrderBy(t => t.Recipent);
				break;
			case '2': // amount
				orderedTransactions = descending ? SortedTransactions.OrderByDescending(t => t.Amount) : SortedTransactions.OrderBy(t => t.Amount);
				break;
			case '3': // category
				orderedTransactions = descending ? SortedTransactions.OrderByDescending(t => t.Category) : SortedTransactions.OrderBy(t => t.Category);
				break;
			case '4': // date
				orderedTransactions = descending ? SortedTransactions.OrderByDescending(t => t.Date) : SortedTransactions.OrderBy(t => t.Date);
				break;
			default: // then let's just sort by date ascending
				orderedTransactions = SortedTransactions.OrderBy(t => t.Date);
                break;
		}

		SortedTransactions = orderedTransactions.ToList();
		if (!SortedTransactions.Any())
			Console.WriteLine("... But none match your selection.\n");
		else
		{
			foreach (var transaction in SortedTransactions)
			{
				Console.WriteLine($"Recipent: {transaction.Recipent}\nAmount: {transaction.Amount}\nCategory: {transaction.Category}\nDate: {transaction.Date}\n");
			}
		}
		
		Console.ReadLine();
		Console.Clear();
		break;
	case '2':
/*		if (accBalance == 0)
		{   //No more transactions when broke!
			Console.WriteLine("You have no money left to make transactions with, cancelling...");
			goto START;
		}
*/		Console.Clear();
		Console.WriteLine("You chose to add a new transaction.");
		// Code for adding a new transaction (like expense or income) goes here
		var newTransaction = new Transaction(null, null, 0, null, null);
		accBalance = newTransaction.AddTransaction(transactions, newTransaction, accBalance);

		break;
	case '3':
		Console.WriteLine("\nYou chose to edit an item (edit or remove).");
		// Code for editing an item goes here
		break;
	case '4':
		Console.WriteLine("\nYou chose to save and quit.");
		// Code to save and quit the application goes here

		return;
	default:
		Console.WriteLine("\nSorry, we don't understand that command. Please try again.");
		goto START;
}
Console.WriteLine($"You now have {accBalance} left, how else may we help you?");
goto START;