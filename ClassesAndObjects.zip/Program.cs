﻿using ClassesAndObjects;
using System.Security.Cryptography.X509Certificates;


Console.WriteLine("Hello, World!");
/*
 * 1. Define a class named 'Car' with properties 'Model' and 'Brand'.
 * 2. Create objects of the 'Car' class and assign values to the properties.
 * 3. Print the details of the car using the properties.
 * 4. Create Constructors for the 'Car' class to initialize the properties when an object is created.
 * 5. Create methods for the Car class to display the car's details.
 * 6. Create a list then add objects into this list, then display all of the cars' details in the list.
 * 7. Create separate file for the Car class.
 * 
 */

// Create a öost pf Car objects
//List<string> cars = new List<string>(); // Cannot hold Car objects, only strings
List<Car> cars = new List<Car>();


// Creating an object of the Car class
Car car1 = new Car();

// Assign values to the properties, setting data for 'car1'
car1.Brand = "Toyota";
car1.Model = "Supra";

cars.Add(car1);

//Printing details of the car using its properties - getting data for 'car1'
//Console.WriteLine(car1.GetCarDetails());


// Creating another object of the Car class using the constructor to initialize the properties
Car car2 = new Car("Honda", "Civic");
Console.WriteLine("\n" + car2 + " found, and it is a " + car2.Brand + " " + car2.Model);

cars.Add(car2);

Car car3 = new Car("Ford");
//Console.WriteLine(car3.GetCarDetails());

cars.Add(car3);

Car car4 = new Car("Tesla", "Model S");
//Console.WriteLine(car4.ToString());

cars.Add(car4);

//Console.WriteLine(1.ToString());

foreach (Car car in cars)
{
    Console.WriteLine(car.GetCarDetails());
}

Console.ReadLine();
/*
class Car
{
    public Car()
    {
    }

    public Car(string brand)
    {
        Brand = brand;
    }

    public Car(string brand, string model)
    {
        Brand = brand;
        Model = model;
    }

    // Properties
    public string Brand { get; set; }
    public string Model { get; set; }

    // Method to display the details of the car
    public string GetCarDetails()
    {
        return $"{Brand} {Model}";
    }

    // Override the ToString method to provide
    public override string ToString()
    {
        return Brand + " " + Model;
    }
}
*/