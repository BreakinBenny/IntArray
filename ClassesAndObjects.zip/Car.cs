﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassesAndObjects
{
	internal class Car
	{
		public Car()
		{
		}

		public Car(string brand)
		{
			Brand = brand;
		}

		public Car(string brand, string model)
		{
			Brand = brand;
			Model = model;
		}
		
		// Properties
		public string Brand { get; set; }
		public string Model { get; set; }
		
		// Method to display the details of the car
		public string GetCarDetails()
		{
			return $"{Brand} {Model}";
		}

		// Override the ToString method to provide
		public override string ToString()
		{
			return Brand + " " + Model;
		}

	}
}
