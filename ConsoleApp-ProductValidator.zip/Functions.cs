﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Linq;

namespace ConsoleApp_ProductValidator
{
	public static class Functions
	{
		public static string[] AddProduct(int capacity)
		{
			var products = new string[capacity];
			var usedNames = new HashSet<string>(StringComparer.OrdinalIgnoreCase); // To track used product names, ignoring case
			var ValidLetters = new Regex("^[A-Za-z]+$");
			int index = 0;
			bool wantsExit = false;

			Console.WriteLine("Add products to the program's array, close with 'exit' or fill until array is full.\n");

			while (index < capacity && !wantsExit)
			{
				// Let's add the letters first, then we can add the numbers
				switch (index)
				{
					case 0:
						Console.Write("Name the first product (letters A-Z only!): ");
						//Console.Write("Now add the numbers (Must be between 200 and 500!): ");
					break;
					case int _ when index == capacity - 1:
						Console.Write("\nAdd the last product (letters only, from A-Z!): ");
						//Console.Write("Now add the numbers (Must be between 200 and 500!): ");
					break;
					default:
						Console.Write("\nAdd another product (letters only, from A-Z!): ");
					break;
				}

				var left = Console.ReadLine()?.Trim();
				if (string.Equals(left, "exit", StringComparison.OrdinalIgnoreCase)) { wantsExit = true; break; }

				if (string.IsNullOrEmpty(left) || !ValidLetters.IsMatch(left))
				{
					Console.ForegroundColor = ConsoleColor.Red;
					Console.WriteLine("Input rejected. Product must have at least one non-accented letter in its name (A-Z), no spaces, nor numbers.\n");
					Console.ResetColor();
					continue;
				}
				if (usedNames.Contains(left))
				{
					Console.ForegroundColor = ConsoleColor.Red;
					Console.WriteLine("That product already exists in the array. Please enter a different product name.");
					Console.ResetColor();
					continue;
				}

				left = left.ToUpperInvariant(); // All good! Convert input to uppercase for consistency

				// Now let's add the integer on the right!
				while (!wantsExit)
				{
					Console.ForegroundColor = ConsoleColor.DarkYellow;
					Console.Write("Enter a number (200-500) or 'exit': ");
					var right = Console.ReadLine()?.Trim();
					if (string.Equals(right, "exit", StringComparison.OrdinalIgnoreCase)) { wantsExit = true; break; }

					if (int.TryParse(right, out int num) && num > 199 && num < 501)
                    {
                        Console.WriteLine(left + "(" + right + ")");
						Console.ResetColor();
						products[index++] = $"{left}-{num}";
						usedNames.Add(left); // Should stop duplicated names
						break; // Done, next product!
					}
					Console.ForegroundColor = ConsoleColor.Red;
					Console.WriteLine("NaN or value out of range. Make sure you only input numbers and the value is between 200 and 500.\n");
					Console.ForegroundColor = ConsoleColor.Yellow;
				}
			}
			if (index == products.Length)
			{
				Console.ForegroundColor = ConsoleColor.Green;
				Console.WriteLine("\nArray is full! No more products can be added.");
				Console.ResetColor();
			}

			Array.Resize(ref products, index); // Resize the array to the number of entered elements
			Console.WriteLine("\nUnsorted product list:\n-----------------------------");
			foreach (string product in products)
			{
				Console.WriteLine(product);
			}

			// create a copy of the original array and sort it
			var myProductsCopy = new string[products.Length];
			products.CopyTo(myProductsCopy, 0); // Copies the elements of myCars to myCarsCopy, starting at index 0
			Array.Sort(myProductsCopy); // Sort the copied array
			products.OrderBy(product => product).ToArray(); // Sort the original array using LINQ
			Console.WriteLine("\n\nSorted product list:\n");
			foreach (var product in myProductsCopy)
				Console.WriteLine(product);


			Console.ReadLine(); // Wait for user input before closing the console
			Console.WriteLine("Returning to main menu...\n");
			return products;
		}
		public static void ViewProducts(string[] products)
		{

			Console.WriteLine("View the products alphabetically or by product number? (1 for alphabetically, 2 for product number)");
			string userInput = Console.ReadLine();

			IEnumerable<string> sorted = products; // ensure 'sorted' is always assigned

			switch (userInput)
			{
				case "1":
					if (products.Length > 1)
						sorted = products.OrderBy(p => p); // Sort the original array using LINQ
				break;
				case "2":
					if (products.Length > 1)
					{
						sorted = products.OrderBy(p =>
						{	// Sort by product number, non-numeric values go to the end
							var parts = p.Split('-', 2);
							return (parts.Length > 1 && int.TryParse(parts[1], out var n)) ? n : int.MaxValue;
						});
					}
				break;
				case "e":
					Console.WriteLine("Cancelled.\n");
				break;
			}

			Console.WriteLine("\nProducts:\n------------------------");
			foreach (var product in sorted)
				Console.WriteLine(product);
		}
		public static void SearchProduct(string[] products)
		{	// Ska vi söka efter varor med första bokstav alternativ kombination av dem? --Fox
			Console.WriteLine("What do you want to search for? (1 for product name, 2 for product number)");
			string userInput = Console.ReadLine();

			switch (userInput)
			{
				case "1":
					Console.Write("Enter the product name (or first letters in the product's name) to search for: ");
					string nameSearch = Console.ReadLine()?.Trim();
					if (!string.IsNullOrEmpty(nameSearch))
					{
						var searched = products.Where(p => p.StartsWith(nameSearch, StringComparison.OrdinalIgnoreCase)).ToArray();
						if (searched.Length > 0)
						{
							Console.Clear();
							Console.WriteLine("\nProduct list filtered to '" + nameSearch + "':");
							foreach (var product in searched)
								Console.WriteLine(product);
						}
						else
						{
							Console.ForegroundColor = ConsoleColor.Red;
							Console.WriteLine("No products with that letter combination found.");
							Console.ResetColor();
						}
					}
				break;
				case "2":
					Console.Write("Enter the product number to search for: ");
					string numberSearch = Console.ReadLine()?.Trim();
					if (!string.IsNullOrEmpty(numberSearch) && int.TryParse(numberSearch, out int desiredNumber))
					{
						var searched = products.Where(p =>
						{
							if (string.IsNullOrEmpty(p)) return false;
							int dashIndex = p.IndexOf('-');
							if (dashIndex < 0 || dashIndex == p.Length - 1) return false;
							string numPart = p.Substring(dashIndex + 1);
							return int.TryParse(numPart, out int num) && num == desiredNumber;
						}).ToArray();


						if (searched.Length > 0)
						{
							Console.Clear();
							Console.WriteLine("\nProducts with the number '" + numberSearch + "':");
							foreach (var product in searched)
								Console.WriteLine(product);
						}
						else
							Console.WriteLine("\nNo products with that value found.");
						break;
					}
					else
					{
						Console.ForegroundColor = ConsoleColor.Red;
						Console.WriteLine("\nYou have not specified a number combination.");
						Console.ResetColor();
					}
				break;
				case "e":
					Console.WriteLine("Cancelled.\n");
				return;
			}


			//Console.WriteLine("Results matching your search:\n");
		}
		public static void SaveProducts()
		{
			Console.WriteLine("Save the product list as a TXT or JSON file? (1 for TXT, 2 for JSON)");
			Console.ReadLine();

			Console.WriteLine("Saving...\n");

			Console.Write("Saved.");
		}
		public static void DeleteProduct(string[] products)
		{
			Console.WriteLine("What product do you wish to delete? (1 for product name, 2 for product number)");
			string userInput = Console.ReadLine();
			switch (userInput)
			{
				case "1":
				case "2":
					foreach (string product in products)
						Console.WriteLine(product);
				break;
				default:
					Console.ForegroundColor = ConsoleColor.Red;
					Console.WriteLine("\nInvalid input.");
					Console.ResetColor();
				break;
			}
            //if (int.TryParse(right, out int num) && num > 199 && num < 501)
            if (int.TryParse(userInput, out int num) && num > 0 && num < 3)
			{
				if (num == 1)
					Console.WriteLine("Input the product you wish to delete by name: ");
				if (num == 2)
					Console.WriteLine("Input the number of the product you wish to delete: ");
				Console.ReadLine();
			}
			else
			{
				Console.ForegroundColor = ConsoleColor.Red;
				Console.WriteLine("Input 1 to delete by product's name, 2 to delete by its number.");
				return;
			}
			// Remove thing from list that matches value or name...
			Console.ReadLine();

			//Console.WriteLine("Deleting that product...\n");
		}
		public static void Exit()
		{
			Console.WriteLine("Exiting...\n");

		}
	}
}