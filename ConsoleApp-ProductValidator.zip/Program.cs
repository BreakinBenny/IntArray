﻿// 1. Create a string array 
// 2. Initialize the array with some string values
// 3. User can enter elements from the console until user enter "exit"
// 4. Print the values of the array to the console
// 5. Exit the program

using System;
using System.Text.RegularExpressions;
using System.Linq;
using ConsoleApp_ProductValidator;

Console.WriteLine("Welcome! What would you like to do? (Use the number keys 1 through 5 to choose a procedure.)");
string[] listProducts = new string[0];

bool inSwitch = true;
while (inSwitch)
{
    string userInput = Console.ReadLine();
	switch (userInput)
	{
		case "1":
			Console.WriteLine("Add a product ");
			Console.Write("How many products do you want to add? (Max 10): ");
			var input = Console.ReadLine();
			if (!int.TryParse(input, out int capacity) || capacity < 1) capacity = 1;
			if (capacity > 10) capacity = 10; // no more than 10 items
			Console.WriteLine($"\nAdding {capacity} product(s)...");
			listProducts = Functions.AddProduct(capacity);
			break;
		case "2":
			if (listProducts == null | listProducts.Length == 0)
			{
				Console.WriteLine("\nNo products to view yet. Please add some products first using option 1.");
				break; 
			}
			Functions.ViewProducts(listProducts);
			break;
		case "3":
			Console.WriteLine("\nOption 3 (Search for a product) selected. (Not implemented yet.)");
			break;
		case "4":
			Console.WriteLine("\nOption 4 (Delete a product) selected. (Not implemented yet.)");
			break;
		case "5":
			Console.WriteLine("\nExiting the program. Goodbye!");
			return; // Exit the Main method, thus ending the program
		default:
			Console.WriteLine("\nInvalid option. Please enter a number between 1 and 5.\n");
			break;
	}
}