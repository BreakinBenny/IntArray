﻿// 1. Create a string array 
// 2. Initialize the array with some string values
// 3. User can enter elements from the console until user enter "exit"
// 4. Print the values of the array to the console
// 5. Exit the program

string[] myProducts = new string[5];
Console.WriteLine("Add products to the program's array, close with 'exit' or fill until array is full.\n");
int index = 0; // Initialize index to keep track of the current position in the array
while (index < 5)
{
    switch(index)
    {
        case 0:
            Console.Write("Add the first product: ");
        break;
        case 4:
            Console.Write("Add the last product: ");
        break;
        default:
            Console.Write("Add another product: ");
        break;
    }
    string data = Console.ReadLine();
    if (data.ToLower().Trim() == "exit")
    {
        break;
    }

    myProducts[index] = data;
    index++;
}

Array.Resize(ref myProducts, index); // Resize the array to the number of entered elements
Console.WriteLine("\nUnsorted product list:\n-----------------------------");
foreach (string product in myProducts)
{
    Console.WriteLine(product);
}

// create a copy of the original array and sort it
var myProductsCopy = new string[myProducts.Length];
myProducts.CopyTo(myProductsCopy, 0); // Copies the elements of myCars to myCarsCopy, starting at index 0
Array.Sort(myProductsCopy); // Sort the copied array
myProducts.OrderBy(product => product).ToArray(); // Sort the original array using LINQ

Console.WriteLine("\n\nSorted product list:\n");
foreach (var product in myProductsCopy)
    Console.WriteLine(product);


Console.ReadLine(); // Wait for user input before closing the console