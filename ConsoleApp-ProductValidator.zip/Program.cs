﻿// 1. Create a string array 
// 2. Initialize the array with some string values
// 3. User can enter elements from the console until user enter "exit"
// 4. Print the values of the array to the console
// 5. Exit the program

using System;
using System.Text.RegularExpressions;
using System.Linq;
using ConsoleApp_ProductValidator;

Console.WriteLine("Welcome! What would you like to do? (Use the number keys 1 through 6 to choose a procedure.)");
string[] listProducts = new string[0];

bool inSwitch = true;
while (inSwitch)
{
    string userInput = Console.ReadLine();
	switch (userInput)
	{
		case "1":
			Console.Clear(); Console.ForegroundColor = ConsoleColor.Cyan;
			Console.Write("You chose 'Add a product'. "); Console.ResetColor();
			Console.Write("How many products do you want to add? (Max 10): ");
			var input = Console.ReadLine();
			if (!int.TryParse(input, out int capacity) || capacity < 1) capacity = 1;
			if (capacity > 10) { capacity = 10; Console.WriteLine("Too many products! Lowering your specified amount to 10..."); } // no more than 10 items
			Console.WriteLine($"\nAdding {capacity} product(s)...");
			listProducts = Functions.AddProduct(capacity);
			break;
		case "2":
			if (listProducts == null || listProducts.Length == 0)
				Console.WriteLine("\nNo products to view yet. Please add some products first using option 1.");
			else
			{
				Console.Clear();
				Functions.ViewProducts(listProducts);
			}
			break;
		case "3":
			if (listProducts.Length < 1)
				Console.WriteLine("\nNo products to search for.");
			else
			{
				Console.WriteLine("\nOption 3 (Search for a product) selected. (Not implemented yet.)");
				Functions.SearchProduct(listProducts);
			}
			break;
		case "4":
			if (listProducts.Length < 1)
				Console.WriteLine("The product list is already empty nor doesn't exist.");
			else
			{
				Console.Clear();
				Console.WriteLine("\nOption 4 (Delete a product) selected. (Not implemented yet.)");
				Functions.DeleteProduct();
			}
			break;
		case "5":
		case "exit":
		case "quit":
			Console.WriteLine("\nExiting the program. Goodbye!");
			return; // Exit the Main method, thus ending the program
		case "6":
			if (listProducts.Length > 0)
				Functions.SaveProducts();
			else
			{
				Console.ForegroundColor = ConsoleColor.Blue;
				Console.WriteLine("\nCannot save, as the product list is empty.");
				Console.ResetColor();
			}
			break;
		default:
			Console.WriteLine("\nInvalid option. Please enter a number between 1 and 5.\n");
			break;
	}
}