﻿/* 1. Get data from user and create a  an object and add it to list
* 
* 
*/

var carsList = new List<Car>();
/*
while (true)
{
	Console.Write("Enter a Car Brand: ");
	string brand = Console.ReadLine() ?? string.Empty;
	if (brand.ToLower().Trim() == "exit")
		break;

	Console.Write("Enter a Car Model: ");
	//string model = Console.ReadLine() ?? "temp350"; // If null or empty, create an empty string or a default value
	string model = Console.ReadLine() ?? string.Empty;
	Console.Write("Enter a Car Year: ");
	int year = int.Parse(Console.ReadLine());
	Console.Write("Enter a Car Speed: ");
	int speed = int.Parse(Console.ReadLine());

	//Car car = new Car(brand, model, year, speed);
	//carsList.Add(car);

	carsList.Add(new Car(brand, model, year, speed));

}

foreach (var car in carsList)
{
	Console.WriteLine($"{car.Brand} {car.Model}, Year: {car.Year}, Speed: {car.Speed}");
}
*/
//Car car1 = new Car("Toyota", "Supra");
//car1.Year = null;

Car car1 = new Car("Toyota", "Supra", 1992, 180, new List<string> { "Alice", "Bob" });
carsList.Add(car1);

Car car2 = new Car("Honda", "Civic", 2018, 110, new List<string> { "Alice", "Bob" });
car2.Passengers = new List<string> { "Charlie", "Dave" };
carsList.Add(car2);

foreach (var car in carsList)
{
	//Console.WriteLine($"{car.Brand} {car.Model}, {car.Year} {car.Speed} {car.Passengers[0]}");
    Console.WriteLine($"{car.Brand} {car.Model}, {car.Year} {car.Speed} {string.Join(", ", car.Passengers)}");
}

// Only get the passengers from the carsList
foreach (var car in carsList)
{
	for (int i = 0; i < car.Passengers.Count; i++)
	{
		Console.WriteLine(car.Passengers[i]);
	}
}

// Setting the Engine property of car3 to a new Engine object with Volume 2000
Car car3 = new Car("Toyota", "Avensis");
car3.Engine.Volume = 2000;

// Getting the Engine volume of car3
Console.WriteLine($"Engine Volume of car3: {car3.Engine.Volume}");


class Car
{
	public Car(string brand, string model)
	{
		Brand = brand;
		Model = model;
	}

	public Car(string brand, string model, int year, int speed)
	{
		Brand = brand;
		Model = model;
		Year = year;
		Speed = speed;
	}

	public Car(string brand, string model, int? year, int speed, List<string> passengers) : this(brand, model)
	{
		Year = year;
		Speed = speed;
		Passengers = passengers;
	}

	public string Brand { get; set; } = "TP";
	public string Model { get; set; } = "temp350";
	public int? Year { get; set; }
	public int Speed { get; set; }
	//public bool isTrue { get; set; }
	public List<string> Passengers { get; set; } // List of strings to hold the names of passengers in the car
	//public string[] Colors { get; set; }
	public Engine Engine { get; set; } = new Engine(); // Initialize the Engine property with a new Engine object

}

class Engine
{
	public int Volume { get; set; }
}