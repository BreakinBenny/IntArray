﻿/*
    *LINQ(Language Integrated Query) in C#
    *LINQ is a uniform query language, introduced with .NET 3.5 that we can use to retrieve data
    *from different data sources.
    *These data sources include the collection of objects, relational databases,
    *ADO.NET datasets, XML files, etc.

    *Aggregate functions such as COunt, Average, Min, Max, Sum,
    *Where, OrderBy(), OrderByDescending()

    *Think in terms of the loops - you don't need a loop with LINQ, LINQ does the looping for you.
    *Lambda expression "=>"
    *https://learn.microsoft.com/en-us/dotnet/csharp/linq/
    *https://learn.microsoft.com/en-us/dotnet/csharp/linq/get-started/introduction-to-linq-queries
    *https://www.freecodecamp.org/news/how-to-use-linq/
    * 
*/

using LINQExample;
/*
List<int> numbers = new List<int>{ 10, -20, 30, -40, 50, 0, 1 };
int max = numbers[0];
foreach (int number in numbers)
{
    if (number > max)
    {
        max = number;
    }
}
*/

List<Car> carsList = new List<Car>();

Car car1 = new Car("Toyota", "Corolla", 1981, 120);
//var car1 = new Car("Toyota", "Corolla", 2020, 120); //var is a keyword. We can use var if we want...
carsList.Add(car1);

carsList.Add(new Car("Honda", "Civic", 1985, 180));

List<Car> extraCars = new List<Car>
{
    new Car("Audi", "A4", 2021, 210),
    new Car("BMW", "3 Series", 2022, 220)
};

// This will not work because Add() method expects a single Car object, not a list of Car objects.
//carsList.Add(extraCars);

carsList.AddRange(extraCars); // This will work because AddRange() method is designed to add multiple items from a collection to the list.

carsList.AddRange(new List<Car>
{
    new Car("Volvo", "XC90", 2023, 200),
    new Car("SAAB", "T900", 2024, 230)
});

// LINQ METHOD SYNTAX
int highestSpeed = carsList.Max(car => car.Speed);
double averageSpeed = carsList.Average(car => car.Speed);
int sumOfSpeeds = carsList.Sum(car => car.Speed);
int countOfCars = carsList.Count();
//int countVolvo = carsList.Where(car => car.Brand.Contains("Volvo")).Count();

Console.WriteLine("Your cars - unsorted");
Console.WriteLine("Brand".PadRight(10) + "Model".PadRight(10) + "Year".PadRight(10) + "Speed");
foreach (Car item in carsList)
{
    Console.WriteLine(item.Brand.PadRight(10) + item.Model.PadRight(10) + item.Year.ToString().PadRight(10) + item.Speed);
}

List<Car> sortedList = carsList.OrderBy(car => car.Brand).ToList();
List<Car> sortedDescendingList = carsList.OrderByDescending(car => car.Year).ToList();
List<Car> sortedList1 = carsList.OrderBy(car => car.Brand).ThenBy(car => car.Year).ThenByDescending(car => car.Speed).ToList();

Console.WriteLine("--------------------------------------");
Console.WriteLine("Your cars - sorted");
Console.WriteLine("Brand".PadRight(10) + "Model".PadRight(10) + "Year".PadRight(10) + "Speed");
foreach (Car item in sortedList)
{
    Console.WriteLine(item.Brand.PadRight(10) + item.Model.PadRight(10) + item.Year.ToString().PadRight(10) + item.Speed);
}

Console.WriteLine("--------------------------------------");
Console.WriteLine("Your cars - sorted by Brand, then year, then speed");
Console.WriteLine("Brand".PadRight(10) + "Model".PadRight(10) + "Year".PadRight(10) + "Speed");
foreach (Car item in sortedList1)
{
    Console.WriteLine(item.Brand.PadRight(10) + item.Model.PadRight(10) + item.Year.ToString().PadRight(10) + item.Speed);
}

var filteredList = carsList.Where(car => car.Year >= 1980 && car.Year <= 1990).ToList();
Console.WriteLine("--------------------------------------");
Console.WriteLine("Your car list filtered to those between 1980-1990");
Console.WriteLine("Brand".PadRight(10) + "Model".PadRight(10) + "Year".PadRight(10) + "Speed");
foreach (Car item in filteredList)
{
    Console.WriteLine(item.Brand.PadRight(10) + item.Model.PadRight(10) + item.Year.ToString().PadRight(10) + item.Speed);
}


Console.ReadLine();