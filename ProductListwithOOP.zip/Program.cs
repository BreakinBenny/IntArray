﻿// 1. Create a string array 
// 2. Initialize the array with some string values
// 3. User can enter elements from the console until user enter "exit"
// 4. Print the values of the array to the console
// 5. Exit the program

using System;
using System.Text.RegularExpressions;
using System.Linq;
//using ProductListwithOOP;

Product product1 = new Product("Liquid", "Milk", 16);
Product product2 = new Product("Solid", "Bread", 18f);

Console.WriteLine("Welcome! What would you like to do? (Use the number keys 1 through 6 to choose a procedure.)");
List<Product> products = new List<Product>();
products.Add(product1);
products.Add(product2);

Console.WriteLine("\n=====PRODUCT LIST=====\nName  |  Type  |  Price");
foreach (Product product in products)
{
	Console.WriteLine(product.ProductDetails());
}

MENU:
string userInput = Console.ReadLine()?.Trim();
switch (userInput)
{
	case "1":
		Console.WriteLine("\nOption 1: Add a product.");
		Product.AddProduct(products);
		break;
	case "2":
		Console.WriteLine("\nOption 2: View products.");
		break;
	case "3":
		Console.WriteLine("\nOption 3: Search for a product.");
		break;
	case "4":
		Console.WriteLine("\nOption 4: Delete a product.");
		break;
	case "5":
		Console.WriteLine("\nOption 5: Statistics selected.");
		break;
	case "6":
		Console.WriteLine("\nOption 6: Save products selected.");
		break;
	case "exit":
	case "q":
	case "quit":
	case "e":
		return;
	default:
		Console.WriteLine("\nInvalid option. Please enter a number between 1 and 6.");
		break;
}
goto MENU;

class Product
{
	public string Type { get; set; }
	public string Name { get; set; }
	public float Price { get; set; }
	public Product(string type, string name, float price)
	{
		Type = type;
		Name = name;
		Price = price;
	}
	public string ProductDetails()
	{
		return $"{Name} | {Type} | {Price} SEK";
	}

	public static void AddProduct(List<Product> products)
    {
		var newProduct = new Product("", "", 0f);
		BEGIN:
        Console.Write("What is the product type? (1: Solid, 2: Liquid): ");
		var type = Console.ReadLine()?.Trim();
		switch (type)
		{
			case "1":
				newProduct.Type = "Solid";
                break;
			case "2":
                newProduct.Type = "Liquid";
				break;
            default:
				Console.ForegroundColor = ConsoleColor.Red;
				Console.WriteLine("Invalid input. Please try again.");
				Console.ResetColor();
				goto BEGIN;
        }
		
        var ValidLetters = new Regex("^[A-Za-z]+$");
		NAME:
        Console.Write("What is the product called? (Letters A-Z only!): ");
		var name = Console.ReadLine()?.Trim();
		if (!string.IsNullOrEmpty(name) || ValidLetters.IsMatch(name))
			Console.WriteLine("Name accepted.");
		else
		{
			Console.ForegroundColor = ConsoleColor.Red;
			Console.WriteLine("Letters A-Z only, try again.");
			Console.ResetColor();
			goto NAME;
		}
            Console.Write("How much is the product worth? (Numbers only!): ");
		var price = Console.ReadLine()?.Trim();
		if (float.TryParse(price, out float priceValue))
		{

		}
		newProduct.Name = name; newProduct.Price = priceValue;
        products.Add(newProduct);

		Console.WriteLine("\nUpdated product list: ");
        foreach (Product product in products)
            Console.WriteLine(product.ProductDetails());
        return;
    }

	public static void ViewProducts(List<Product> products)
	{
		Console.WriteLine("=====PRODUCT LIST=====\n Name | Type | Price");
		foreach (Product product in products)
		{
			Console.WriteLine(product.ProductDetails());
		}
	}

	public static void SearchProduct(List<Product> products)
	{
		Console.Write("Enter the name of the product to search for: ");
		string searchTerm = Console.ReadLine();
		var foundProducts = products.Where(p => p.Name.Contains(searchTerm, StringComparison.OrdinalIgnoreCase)).ToList();
		if (foundProducts.Count > 0)
		{
			Console.WriteLine($"Found {foundProducts.Count} product(s) matching '{searchTerm}':");
			foreach (var product in foundProducts)
			{
				Console.WriteLine(product.ProductDetails());
			}
		}
		else
		{
			Console.WriteLine($"No products found matching '{searchTerm}'.");
		}
	}

	public string[] DeleteProduct(List<Product> products)
	{
		Console.Write("Enter the name of the product to delete: ");
		string deleteTerm = Console.ReadLine();
		var productToDelete = products.FirstOrDefault(p => p.Name.Equals(deleteTerm, StringComparison.OrdinalIgnoreCase));
		if (productToDelete != null)
		{
			products.Remove(productToDelete);
			Console.WriteLine($"Product '{deleteTerm}' has been deleted.");
		}
		else
		{
			Console.WriteLine($"No product found with the name '{deleteTerm}'.");
		}
		return products.Select(p => $"{p.Name}-{p.Price}").ToArray();
	}
}

/*
bool inSwitch = true;
while (inSwitch)
{
	string userInput = Console.ReadLine();
	switch (userInput)
	{
		case "1":
			Console.Clear(); Console.ForegroundColor = ConsoleColor.Cyan;
			Console.Write("You chose 'Add a product'. "); Console.ResetColor();
			Console.Write("How many products do you want to add? (Max 10): ");
			var input = Console.ReadLine();
			if (!byte.TryParse(input, out byte capacity) || capacity < 1) capacity = 1;
			if (capacity > 10) { capacity = 10; Console.WriteLine("Too many products! Lowering your specified amount to 10..."); } // no more than 10 items
			Console.WriteLine($"\nAdding {capacity} product(s)...");
			products = Functions.AddProduct(capacity);
		break;
		case "2":
			if (products == null || products.Count == 0)
				Console.WriteLine("\nNo products to view yet. Please add some products first using option 1.");
			else
			{
				Console.Clear();
				Functions.ViewProducts(products);
			}
		break;
		case "3":
			if (products.Count < 1)
				Console.WriteLine("\nNo products to search for.");
			else
				Functions.SearchProduct(products);
		break;
		case "4":
			if (products.Count < 1)
				Console.WriteLine("The product list is already empty or doesn't exist.");
			else
			{
				Console.ForegroundColor = ConsoleColor.DarkRed;
				Console.WriteLine("Option 4 (Delete a product) selected.");
				Console.ResetColor();
				products = Functions.DeleteProduct(products);
			}
		break;
		case "5":
			Console.WriteLine("\nOption 5: Statistics selected.");
			if (products == null || products.Count == 0)
				Console.WriteLine("\nNo products to analyze. Please add some products first using option 1.");
			else
			{
				// Parse the numbers after the dash, ignore entries that don't parse
				var numbers = products.Select(p =>
				{
					if (string.IsNullOrEmpty(p)) return null;
					var dash = p.IndexOf('-');
					if (dash < 0 & dash == p.Count - 1) return null;
					return int.TryParse(p.Substring(dash + 1), out var n) ? (int?)n : null;
				}).Where(n => n.HasValue).Select(n => n.Value).ToArray();

                Console.WriteLine("Number of products in the list: " + products.Count);
				Console.WriteLine("Product with highest number: " + products.OrderByDescending(p => p).FirstOrDefault());
				Console.WriteLine("Product with lowest number: " + products.OrderBy(p => p).FirstOrDefault());

				Console.WriteLine("Average product value: " + numbers.Average().ToString("F2"));
			}
		break;
		case "exit":
		case "quit":
			Console.WriteLine("\nExiting the program. Goodbye!");
			return; // Exit the Main method, thus ending the program
		case "6":
			if (products.Count > 0)
				Functions.SaveProducts();
			else
			{
				Console.ForegroundColor = ConsoleColor.Blue;
				Console.WriteLine("\nCannot save, as the product list is empty.");
				Console.ResetColor();
			}
		break;
		default:
			Console.WriteLine("\nInvalid option. Please enter a number between 1 and 5.\n");
		break;
	}
}
*/