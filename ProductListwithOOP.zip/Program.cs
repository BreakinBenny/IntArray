﻿// 1. Create a string array 
// 2. Initialize the array with some string values
// 3. User can enter elements from the console until user enter "exit"
// 4. Print the values of the array to the console
// 5. Exit the program

using System;
using System.Text.RegularExpressions;
using System.Linq;
using ProductListwithOOP;

Product product1 = new Product("Liquid", "Milk", 16);
Product product2 = new Product("Solid", "Bread", 18f);

Console.WriteLine("Welcome! What would you like to do? (Use the number keys 1 through 6 to choose a procedure.)");
List<Product> products = new List<Product>();
products.Add(product1);
products.Add(product2);

foreach (Product product in products)
{
	Console.WriteLine(product.Print());
}

class Product
{
    public string Type { get; set; }
    public string Name { get; set; }
    public float Price { get; set; }
    public Product(string type, string name, float price)
    {
        Type = type;
        Name = name;
        Price = price;
    }
    public string Print()
    {
        return $"{Type} - {Name}: {Price} SEK";
    }
}

/*
bool inSwitch = true;
while (inSwitch)
{
	string userInput = Console.ReadLine();
	switch (userInput)
	{
		case "1":
			Console.Clear(); Console.ForegroundColor = ConsoleColor.Cyan;
			Console.Write("You chose 'Add a product'. "); Console.ResetColor();
			Console.Write("How many products do you want to add? (Max 10): ");
			var input = Console.ReadLine();
			if (!byte.TryParse(input, out byte capacity) || capacity < 1) capacity = 1;
			if (capacity > 10) { capacity = 10; Console.WriteLine("Too many products! Lowering your specified amount to 10..."); } // no more than 10 items
			Console.WriteLine($"\nAdding {capacity} product(s)...");
			listProducts = Functions.AddProduct(capacity);
		break;
		case "2":
			if (listProducts == null || listProducts.Length == 0)
				Console.WriteLine("\nNo products to view yet. Please add some products first using option 1.");
			else
			{
				Console.Clear();
				Functions.ViewProducts(listProducts);
			}
		break;
		case "3":
			if (listProducts.Length < 1)
				Console.WriteLine("\nNo products to search for.");
			else
				Functions.SearchProduct(listProducts);
		break;
		case "4":
			if (listProducts.Length < 1)
				Console.WriteLine("The product list is already empty or doesn't exist.");
			else
			{
				Console.ForegroundColor = ConsoleColor.DarkRed;
				Console.WriteLine("Option 4 (Delete a product) selected.");
				Console.ResetColor();
				listProducts = Functions.DeleteProduct(listProducts);
			}
		break;
		case "5":
			Console.WriteLine("\nOption 5: Statistics selected.");
			if (listProducts == null || listProducts.Length == 0)
				Console.WriteLine("\nNo products to analyze. Please add some products first using option 1.");
			else
			{
				// Parse the numbers after the dash, ignore entries that don't parse
				var numbers = listProducts.Select(p =>
				{
					if (string.IsNullOrEmpty(p)) return (int?)null;
					var dash = p.IndexOf('-');
					if (dash < 0 & dash == p.Length - 1) return (int?)null;
					return int.TryParse(p.Substring(dash + 1), out var n) ? (int?)n : null;
				}).Where(n => n.HasValue).Select(n => n.Value).ToArray();

                Console.WriteLine("Number of products in the list: " + listProducts.Length);
				Console.WriteLine("Product with highest number: " + listProducts.OrderByDescending(p => p).FirstOrDefault());
				Console.WriteLine("Product with lowest number: " + listProducts.OrderBy(p => p).FirstOrDefault());

				Console.WriteLine("Average product value: " + numbers.Average().ToString("F2"));
			}
		break;
		case "exit":
		case "quit":
			Console.WriteLine("\nExiting the program. Goodbye!");
			return; // Exit the Main method, thus ending the program
		case "6":
			if (listProducts.Length > 0)
				Functions.SaveProducts();
			else
			{
				Console.ForegroundColor = ConsoleColor.Blue;
				Console.WriteLine("\nCannot save, as the product list is empty.");
				Console.ResetColor();
			}
		break;
		default:
			Console.WriteLine("\nInvalid option. Please enter a number between 1 and 5.\n");
		break;
	}
}
*/