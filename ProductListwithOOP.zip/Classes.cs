﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductListwithOOP
{
	internal class Classes
	{
		class Product
		{
			public string Name { get; set; }
			public string Category { get; set; }
			public float Price { get; set; }
			public byte Quantity { get; set; }
			public Product(string name, string category, float price, byte quantity)
			{
				Name = name;
				Category = category;
                Price = price;
				Quantity = quantity;
			}
			public float TotalPrice()
			{
				return Price * Quantity;
			}
		}
		class LiquidProduct : Product
        {   // Liquids have volume, so litres, millilitres, etc. We can use float for this.
            public float Volume { get; set; }
			public LiquidProduct(string name, string category, float price, byte quantity, float volume) : base(name, category, price, quantity)
            {
                Volume = volume;
            }

        }
		class SolidProduct : Product
		{
			public float Weight { get; set; }
			public SolidProduct(string name, string category, float price, byte quantity, float weight) : base(name, category, price, quantity)
			{
				Weight = weight; // Should be kilograms
			}
        }
	}
}
